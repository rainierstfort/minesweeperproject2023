Name: Rainier N. St. Fort
Section: 11947
UFL email: stfortrainier@ufl.edu
System: Google Chrome 118.0.5993.124 (Official Build) (64-bit) 
Compiler: gcc (Debian 10.2.1-6) 10.2.1 20210110
SFML version: SFML 2.5.1
IDE: VS CODE
Other notes: The last two rows of my game window, when clicked, will reveal mines but does not end the game. Could not figure out how to fix, program acts as if those mines do not exist in the functionality of the program. Also to win, all of the mines in these rows must be revealed, and it should work. After a regular mine is clicked, you will not be able to click on the screen anymore so please exit the window and re open to test leaderboard window! Every feature is implemented.